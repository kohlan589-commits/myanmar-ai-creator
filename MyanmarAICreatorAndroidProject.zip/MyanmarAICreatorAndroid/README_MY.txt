Myanmar AI Creator - Android project

ဒီ ZIP ထဲမှာ Android Studio project အပြည့်အစုံနဲ့ app ရဲ့ HTML prototype ပါပါတယ်။
ဒါက APK ဖိုင်မဟုတ်သေးပါ။ ဒီနေရာမှာ APK ကို compile လုပ်ပြီး စမ်းသပ်အတည်ပြုထားခြင်း မရှိပါ။

APK ထုတ်ရန် (Computer/Laptop လိုအပ်နိုင်သည်)
1. ZIP ကို ဖြည်ပါ။
2. Android Studio ကိုဖွင့်ပြီး "Open" ကိုနှိပ်ပါ။
3. MyanmarAICreator folder ကိုရွေးပါ။
4. Gradle sync ပြီးသည့်အထိ စောင့်ပါ။
5. Build > Build Bundle(s) / APK(s) > Build APK(s) ကိုနှိပ်ပါ။
6. APK ကို app/build/outputs/apk/debug/ အောက်မှာ ရှာပါ။

ဖုန်းတစ်လုံးတည်းသာရှိပါက ဒီ source project ကို ချက်ချင်း APK ပြောင်းရန် ခက်ခဲနိုင်ပါတယ်။
ဖုန်းမှ Android Studio ကို တိုက်ရိုက်အသုံးပြု၍မရနိုင်သောကြောင့် အခြား cloud build service သို့မဟုတ် computer တစ်လုံးကို အသုံးပြုရနိုင်ပါတယ်။

လုပ်ဆောင်ချက်
- AI Image Prompt demo
- AI Video Prompt demo
- Burmese story prompt template
- Character consistency prompt template
- Copy / Save / local browser history

အရေးကြီး
- ယခု version သည် demo prompt template များကိုသာ ဖန်တီးပေးသည်။
- Gemini သို့မဟုတ် image/video generation API မချိတ်ဆက်ရသေးပါ။
- Prompt history ကို WebView local storage ထဲတွင် သိမ်းသည်။
